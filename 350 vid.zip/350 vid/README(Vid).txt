In this video we will demonstrate how to run our program.

You can start the program using any IDE as well, but for the sake of generalization, we used CMD.

Our program supports any amount of users, but for the sake of simplicity, we chose 3 players.
First, open CMD, cd into the project file, then run "python server.py" to start the server and choose your desired number of players (3 in this case).

Then, run "python client.py" on another CMD instance to run the client server, make sure you do this depending on your desired number of players (same amount).

After that, enter the names and start playing. The cummulative scores will be displayed on the client's interface to show his progress and how he compares to the opposition.

When the game is over, the winner is declared. Furthermore, when you open the CMD from where you started the server, the RTT of each player, the round scores in descending order for each round, and the cummulative scores in descending order.